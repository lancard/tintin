echo "Please Note:  Readline wasn't found in either of the normal spots."
echo "(/usr/include or /usr/local/include)  You will need to specific"
echo "the location of the readline library to configure with --libdir and"
echo "--includedir then do a make clean;configure from the tintin++ src tree."
echo "Please take a look at the INSTALL file for instructions."
sleep 5


